$dir=$ARGV[0];
system("mkdir $dir/res_file");
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
#	print $token[0]."\n";
}
close(param);

if($params{"file_type"} eq "bed")
{
	system("perl bed2gtf.pl $dir");
}

if($params{"exp_cutoff_select"} eq "on")
{
	system("perl pipline/exp_threshold_single.pl $dir") if($params{"upload_type"} eq "single");
	system("perl  pipline/exp_threshold_multi.pl $dir") if($params{"upload_type"} eq "multiple");
	$mygtf="$dir/res_file/multi.combined.gtf" if($params{"upload_type"} eq "multiple");
	$mygtf="$dir/res_file/filter_exp.gtf" if($params{"upload_type"} eq "single");


}
else
{
	if($params{"upload_type"} eq "multiple")
	{
		$file_path=$params{"file_path"};
		$num=$params{"multi_num"};
		open(res,">$file_path/gtf.txt");
		for($s=3;$s<=$num;$s++)
		{
			print res $file_path."/upload_file/".$s.".gtf\n";
		}
		close(res);
		system("perl pipline/cuffcompare_multi.pl $dir $file_path/gtf.txt"); # combine all upload files
		$mygtf="$dir/res_file/multi.combined.gtf";

	}
	if($params{"upload_type"} eq "single")
	{
		$mygtf="$dir/upload_file/transcripts.gtf";
	}

}

if($params{"rec_cutoff_select"} eq "on" and $params{"upload_type"} eq "multiple")
{
	system("perl pipline/filter_rec.pl $dir") ;
	$mygtf="$dir/res_file/filter_rec.gtf";
}
if($params{"known_code_select"} eq "on")
{
	system("perl pipline/filter_coding.pl $dir $mygtf") ;
	$mygtf="$dir/res_file/filter_overlap_coding.gtf";
}
if($params{"known_other_noncode_select"} eq "on")
{
	system("perl pipline/filter_other_nc.pl $dir $mygtf") ;
	$mygtf="$dir/res_file/filter_overlap_other_nc.gtf";
}
if($params{"min_seqlen_select"} eq "on")
{
	system("perl pipline/filter_length.pl $dir $mygtf") ;
	$mygtf="$dir/res_file/filter_len.gtf";
}
if($params{"min_exon_select"} eq "on")
{
	system("perl pipline/filter_exon.pl $dir $mygtf") ;
	$mygtf="$dir/res_file/filter_exon.gtf";
}
if($params{"known_noncode_select"} eq "on")
{
	system("perl pipline/filter_lnc.pl $dir $mygtf") ;
	$mygtf="$dir/res_file/filter_overlap_lnc.gtf";
}

print $mygtf."\n";
system("perl pipline/get.transeq.pl $dir $mygtf") ;
$seq=$dir."/res_file/transcripts.fasta";

if($params{"max_orf_select"} eq "on")
{

	@token=split(/\//,$seq);
	$seq_name=$token[@token-1];
	$dir2=$token[@token-2];
	$seq2="$dir2/$seq_name";
	system("perl pipline/predict_orf.pl $dir $seq2 ");
	system("perl pipline/filter_orf.pl $dir $seq $mygtf");
	$seq="$dir/res_file/filter_orf.fasta";
	$mygtf="$dir/res_file/filter_orf.gtf";	
}

if($params{"overlap_mycode_select"} eq "on" and $params{"org_select"} eq "custom" )
{
	system("perl pipline/known_blastx.pl $dir $seq $mygtf") ;
	$mygtf="$dir/res_file/filter_myprotein_blastx.gtf";
	$seq="$dir/res_file/filter_myprotein_blastx.fasta";	
}
if($params{"overlap_code_select"} eq "on")
{
	system("perl pipline/blastx.pl $dir $seq $mygtf") ;
	$mygtf="$dir/res_file/filter_uniprot_blastx.gtf";
	$seq="$dir/res_file/filter_uniprot_blastx.fasta";	
}

if($params{"tool_select"} eq "on")
{
	@tools=split(/;/,$params{"tool"});
	foreach my $t(@tools)
	{
		if($t eq "plek")
		{
			system("python software/PLEK.1.2/PLEK.py -fasta $seq -o $dir/res_file/plek.res -threads 8");
			system("perl pipline/filter_plek.pl $dir $seq $mygtf");
  			$seq="$dir/res_file/filter_plek.fasta";
			$mygtf="$dir/res_file/filter_plek.gtf";	
		}		
		if($t eq "cpc")
		{
			system("perl pipline/cpc.pl $dir $seq $mygtf");
			system("perl pipline/filter_cpc.pl $dir $seq $mygtf");
  			$seq="$dir/res_file/filter_cpc.fasta";
			$mygtf="$dir/res_file/filter_cpc.gtf";	
		}
		if($t eq "cnci")
		{

			system("/home/software/Python-2.7.2/python software/CNCI-master/CNCI.py -f $seq -o $dir/res_file/cnci.res -p 8 -m ve");
			system("perl pipline/filter_cnci.pl $dir $seq $mygtf");
  			$seq="$dir/res_file/filter_cnci.fasta";
			$mygtf="$dir/res_file/filter_cnci.gtf";	
		}

	}
}

#75793

