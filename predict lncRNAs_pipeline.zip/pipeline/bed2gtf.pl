
$dir=$ARGV[0];

open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];

}
close(param);
$upload=$params{"upload_type"}; #single or multiple
$file_type=$params{"file_type"}; #gtf bed
$num=$params{"multi_num"};
if($upload eq "single")
{
	$in=$dir."/upload_file/transcript.bed";
	$out=$dir."/upload_file/transcript.gtf";
	bed2gtf($in,$out);
}
if($upload eq "multiple")
{
	for($s=1;$s<=$num;$s++)
	{
		$in=$dir."/upload_file/$s.bed";
		$out=$dir."/upload_file/$s.gtf";
		bed2gtf($in,$out);
	}
}


sub bed2gtf{
open(gtf,">$_[1]");
open(bed,"$_[0]");
while(<bed>)
{
	chomp;
	@token=split(/\t/,$_);
	print gtf $token[0]."\tbed\t$token[4]\t$token[1]\t$token[2]\t1000\t$token[3]\t.\tgene_id \"$token[6]\"; transcript_id \"$token[5]\"; FPKM \"$token[7]\";" if($token[6] ne "" and $token[7] ne "");
	print gtf $token[0]."\tbed\t$token[4]\t$token[1]\t$token[2]\t1000\t$token[3]\t.\tgene_id \"$token[6]\"; transcript_id \"$token[5]\";" if($token[6] ne "" and $token[7] eq "");
	$geneid=$token[5]."_gene";
	print gtf $token[0]."\tbed\t$token[4]\t$token[1]\t$token[2]\t1000\t$token[3]\t.\tgene_id \"$geneid\"; transcript_id \"$token[5]\";" if($token[6] eq "" and $token[7] eq "");
	print gtf $token[0]."\tbed\t$token[4]\t$token[1]\t$token[2]\t1000\t$token[3]\t.\tgene_id \"$geneid\"; transcript_id \"$token[5]\"; FPKM \"$token[7]\";" if($token[6] eq "" and $token[7] ne "");
	

}
close(bed);
close(gtf);
}
