use List::Util qw[min max];
$dir=$ARGV[0];
$gtf=$ARGV[1];
open(gtf,"$gtf");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$gid=(split(/"/,$token[8]))[1];
	$tid=(split(/"/,$token[8]))[3];
	$len{$tid}=$len{$tid}+$token[4]-$token[3] if($token[2] eq "exon");
	$exon{$tid}++ if($token[2] eq "exon");
	$strand{$tid}=$token[6];
	$exp{$tid}=(split(/"/,$token[8]))[5] if($token[2] eq "transcript");
	$exoninfo{$tid}=$exoninfo{$tid}.";".$token[3]."-".$token[4] if($token[2] eq "exon");
	$min{$tid}=1000000000000000 if(!exists($min{$tid}));
	$max{$tid}=0 if(!exists($max{$tid}));
	$min{$tid}=min($min{$tid},$token[3]);
	$max{$tid}=max($max{$tid},$token[4]);
	$chr{$tid}=$token[0];
	$gnum{$gid}++;
	$tid2gid{$tid}=$gid;
}
close(gtf);
open(res,">$dir/res_file/lnc.gtf.info.txt");
while(my($k,$v)=each(%len))
{
	$einfo=substr($exoninfo{$k},1,length($exoninfo{$k})-1);
	print res $k."\t$tid2gid{$k}\t$chr{$k}\t$min{$k}\t$max{$k}\t$strand{$k}\t$exon{$k}\t$einfo\t$v\t$exp{$k}\n";
}
close(res);
