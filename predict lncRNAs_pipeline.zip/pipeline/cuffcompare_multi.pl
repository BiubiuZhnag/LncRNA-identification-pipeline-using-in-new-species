$dir=$ARGV[0];
#system("mkdir $dir/cuffcompare");
$files=$ARGV[1];
system("cuffcompare -i $files -o $dir/multi -C");

