$dir=$ARGV[0];
$cnci=$dir."/res_file/cnci.res/CNCI.index";
$seq=$ARGV[1];
$gtf=$ARGV[2];
open(cnci,"$cnci");
while(<cnci>)
{
	chomp;
	@token=split(/\t/,$_);
	$token[0]=(split(/\//,$token[0]))[0];
#	print "cnci".$token[0]."\n";
	$non{$token[0]}=0 if(grep(/noncoding/,$_));
}
close(cnci);

sub filter_seq{
open(seq,"$_[0]");
open(res,">$_[1]");
while(<seq>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$tmp_id=$id;
		$id=(split(/\s+/,$id))[0];
		$id=(split(/\//,$id))[0] if(grep(/\//,$id));
		#	print $id."\n";

	
		
	}
	else
	{
		if(exists($non{$id}))
		{
			print res ">$tmp_id\n$_\n";
		}

	}

}
close(seq);
close(res);
open(res,">$_[3]");
open(gtf,"$_[2]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];

        print res $_."\n" if(exists($non{$tid}));
}
close(gtf);
close(res);
}

$res_fasta=$dir."/res_file/filter_cnci.fasta";
$res_gtf=$dir."/res_file/filter_cnci.gtf";
filter_seq($seq,$res_fasta,$gtf,$res_gtf);




