$dir=$ARGV[0];
$seq=$ARGV[1];
$gtf=$ARGV[2];
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
	
}
close(param);
$orf_cutoff=$params{"max_orf"};

open(cds,"$dir/transcripts.fasta.transdecoder_dir/longest_orfs.cds");
while(<cds>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$id=(split(/\|/,$id))[0];
		$id=(split(/\//,$id))[0] if(grep(/\//,$id));
		$len=(split(/\s+/,$_))[3];
		$len=(split(/:/,$len))[1];
		$orf{$id}=0 if($len>=$orf_cutoff);
		#	print $id."\t".$len."\t$orf_cutoff\n";
	}
}
close(cds);

sub filter_seq{
open(seq,"$_[0]");
open(res,">$_[1]");
while(<seq>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$tmp_id=$id;
		$id=(split(/\s+/,$id))[0];
		$id=(split(/\//,$id))[0] if(grep(/\//,$id));

	
		
	}
	else
	{
		if(!exists($orf{$id}))
		{
			print res ">$tmp_id\n$_\n";
		}

	}

}
close(seq);
close(res);
open(res,">$_[3]");
open(gtf,"$_[2]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];
        print res $_."\n" if(!exists($orf{$tid}));
}
close(gtf);
close(res);
}
$res_fasta="$dir/res_file/filter_orf.fasta";
$res_gtf="$dir/res_file/filter_orf.gtf";
filter_seq($seq,$res_fasta,$gtf,$res_gtf);



