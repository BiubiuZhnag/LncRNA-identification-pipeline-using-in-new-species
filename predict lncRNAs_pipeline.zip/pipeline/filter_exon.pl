$dir=$ARGV[0];
$gtf=$ARGV[1];
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
	
}
close(param);
$num=$params{"min_exon"};
$res_gtf="$dir/res_file/filter_exon.gtf";
open(gtf,"$gtf");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	if($token[2] eq "exon")
	{
		$tid=(split(/"/,$token[8]))[3];
		$exon{$tid}++;
	}
}
close(gtf);
open(gtf,"$gtf");
open(res,">$res_gtf");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];
	print res $_."\n" if($exon{$tid}>=$num);

}
close(gtf);
close(res);
