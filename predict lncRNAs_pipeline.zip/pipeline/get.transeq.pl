use Bio::DB::Fasta;
$dir=$ARGV[0];
$gtf=$ARGV[1];
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];

}
close(param);

$genome=$params{"genome"};
$org=$params{"organism"};
$ver=$params{"version"};
$seq="$dir/res_file/transcripts.fasta";
if($genome eq "known")
{
	$geno_fasta="data/genome/$org.$ver.fa";
}
else
{
	$geno_fasta=$genome;
}
print $genome."\n";
$db=Bio::DB::Fasta->new($geno_fasta);
my @ids     = $db->ids;
# print join("\n",@ids);

open(gtf,"$gtf");
while(<gtf>)
{
	chomp;
	@token=split(/\t/,$_);
	# print $_;
	if($token[2] eq "exon")
	{
		$tid=(split(/"/,$token[8]))[3];
		$loc{$tid}=$loc{$tid}.";".$token[0]."\t$token[3]\t$token[4]";
		$strand{$tid}=$token[6];
	}
}
close(gtf);
open(res,">$seq");
# open(res1,">/usr/local/apache-tomcat-7.0.57/webapps/scz/WEB-INF/classes/user/2017-12/sm/exp1");
while(my($k,$v)=each(%loc))
{
	@token=split(/;/,$v);
	$allseq="";
	$allseq2="";
	$tid=$k;
	# $tid="TCONS_00163668";
#	print $tid."\n";
	if($strand{$tid} eq "+")
	{
		for($i=1;$i<@token;$i++)
		{
			$chr=(split(/\t/,$token[$i]))[0];
			$s=(split(/\t/,$token[$i]))[1];
			$e=(split(/\t/,$token[$i]))[2];
			$seq=$db->seq($chr, $s =>$e);
				# print res1 $tid."\t".$chr."\t$s\t$e\t$seq\n";		
			$allseq=$allseq.$seq;
	#		print $seq."\n";
		}
		print res ">$k\t$strand{$tid}\n$allseq\n";
	}
	if($strand{$tid} eq "-")
	{
		for($i=1;$i<@token;$i++)
		{
			$chr=(split(/\t/,$token[$i]))[0];
			$s=(split(/\t/,$token[$i]))[1];
			$e=(split(/\t/,$token[$i]))[2];
			$seq=$db->seq($chr, $e =>$s);		
			$allseq=$seq.$allseq;
		}
		print res ">$k\t$strand{$tid}\n$allseq\n";
	}		
	if($strand{$tid} eq ".")
	{
		for($i=1;$i<@token;$i++)
		{
			$chr=(split(/\t/,$token[$i]))[0];
			$s=(split(/\t/,$token[$i]))[1];
			$e=(split(/\t/,$token[$i]))[2];
			$seq=$db->seq($chr, $e =>$s);
			$seq2=$db->seq($chr, $s =>$e);		
			$allseq=$seq.$allseq;
			$allseq2=$allseq2.$seq2;
		}
		print res ">$k\t-\n$allseq\n";
		print res ">$k\t+\n$allseq2\n";
	}		

}
close(res);



