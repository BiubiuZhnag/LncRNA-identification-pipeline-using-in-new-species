$dir=$ARGV[0];
$gtf=$ARGV[1];


open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
}
close(param);
$is_filter_non=$params{"known_noncode_select"};
$known_noncode_cutoff=$params{"known_noncode_cutoff"};
$org=$params{"organism"};
$org_select=$params{"org_select"}; 
$version=$params{"version"}; 


if($org_select eq "known")
{
	$ref_gtf="data/lnc/NONCODE2016_".$org.".lncAndGene.gtf";
	system("cuffcompare $gtf -r $ref_gtf -o $dir/res_file/lnc -C");
}


@token=split(/\//,$gtf);
$gtf_name=$token[@token-1];
$dir2=$token[@token-2];
$tmap=$dir."/$dir2/lnc.".$gtf_name.".tmap";
#$tmap=$dir."/res_file/ref.tracking";
$filter_known_lnc_gtf="$dir/res_file/filter_overlap_lnc.gtf";
%want=();
sub getcompare{
open(compare,"$_[0]"); #merged_asm/merged_ref.merged.gtf.tmap
while(<compare>) 
{
        chomp;
        @token=split(/\t/,$_);
	@info=split(/;/,$known_noncode_cutoff);
	$tag=0;
	for($ii=0;$ii<@info;$ii++)
	{
		if($token[2] eq $info[$ii])
		{
			$tag=1;
		}
		$want{$token[3]}=0 if($tag==1);
		$want{$token[4]}=0 if($tag==1);
	}

}
close(compare);
}



sub filter_pro{
open(res,">$_[1]"); #nc/filter.known.transcripts.gtf
open(gtf,"$_[0]");
$len=0;
while(<gtf>)
{
        chomp;
        @token=split(/\t/,$_);
        $transcript_id=(split(/\s+/,$token[8]))[3];
        $transcript_id=~s/"//g;
        $transcript_id=~s/;//g;
        print res $_."\n" if(exists($want{$transcript_id}));
}
close(gtf);

close(res);
}


getcompare($tmap);
filter_pro($gtf,$filter_known_lnc_gtf);


