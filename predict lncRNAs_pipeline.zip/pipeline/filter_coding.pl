$dir=$ARGV[0];
$gtf=$ARGV[1];


open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
}
close(param);
$rec_cutoff=$params{"rec_cutoff"};
$file_path=$params{"file_path"};
$org=$params{"organism"};
$known_code_cutoff=$params{"known_code_cutoff"};
$org_select=$params{"org_select"}; 
$version=$params{"version"}; 
$known_pro_filetype=$params{"known_pro_filetype"};
$progtf=$params{"known_gene_gtf"};

if($org_select eq "known")
{
	$ref_gtf="data/gtf/$org/$org.ucsc.refseq.$version.protein-coding.gtf";
	system("cuffcompare $gtf -r $ref_gtf -o $dir/res_file/ref -C");
}
else
{
	if($known_pro_filetype eq "gtf")
	{
		$ref_gtf="$progtf";
		system("cuffcompare $gtf -r $ref_gtf -o $dir/res_file/ref -C");
	}
}


@token=split(/\//,$gtf);
$gtf_name=$token[@token-1];

$dir2=$token[@token-2];

$tmap=$dir."/$dir2/ref.".$gtf_name.".tmap";
#$tmap=$dir."/res_file/ref.tracking";
$filter_known_coding_gtf="$dir/res_file/filter_overlap_coding.gtf";
%want=();
sub getcompare{
open(compare,"$_[0]"); #merged_asm/merged_ref.merged.gtf.tmap
while(<compare>) 
{
        chomp;
        @token=split(/\t/,$_);
	@info=split(/;/,$known_code_cutoff);
	$tag=0;
	for($ii=0;$ii<@info;$ii++)
	{
		if($token[2] eq $info[$ii])
		{
			$tag=1;
		}
		$want{$token[3]}=0 if($tag==1);
		$want{$token[4]}=0 if($tag==1);
	}

}
close(compare);
}



sub filter_pro{
open(res,">$_[1]"); #nc/filter.known.transcripts.gtf
open(gtf,"$_[0]");
$len=0;
while(<gtf>)
{
        chomp;
        @token=split(/\t/,$_);
        $transcript_id=(split(/\s+/,$token[8]))[3];
        $transcript_id=~s/"//g;
        $transcript_id=~s/;//g;
        print res $_."\n" if(exists($want{$transcript_id}));
}
close(gtf);

close(res);
}


getcompare($tmap);
filter_pro($gtf,$filter_known_coding_gtf);

