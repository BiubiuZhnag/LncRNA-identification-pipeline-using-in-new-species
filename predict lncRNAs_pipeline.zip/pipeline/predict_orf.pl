$seq=$ARGV[1];
$dir=$ARGV[0];
chdir($dir);

system("/home/software/TransDecoder-2.0.1/TransDecoder.LongOrfs -t $seq");
chdir("../../../../../../");
