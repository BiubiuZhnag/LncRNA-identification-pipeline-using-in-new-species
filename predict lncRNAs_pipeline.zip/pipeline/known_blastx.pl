$dir=$ARGV[0];
$seq=$ARGV[1];
$gtf=$ARGV[2];
%notwantid=();
%notwant=();
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];

}
close(param);
$identity=$params{"overlap_mycode_identity"};
$len_ratio=$params{"overlap_mycode_length_ratio"};
$evalue=$params{"overlap_mycode_evalue"};

system("makeblastdb -in $dir/data/protein.fasta -dbtype prot -out $dir/data/myprotein"); 
$db="$dir/data/myprotein";
$out="$dir/res_file/blastx.myprotein.txt";
system("blastx -query $seq  -db $db -num_threads 8 -outfmt 7 -out $out");




open(seq,"$seq");
while(<seq>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$id=(split(/\s+/,$id))[0];
	}
	else
	{
		$length{$id}=length($_);
	}

}
close(seq);
%notwant=();
sub get_blast_res{
open(bl,"$_[0]");
while(<bl>)
{
        @token=split(/\t/,$_);
        if(!grep(/^#/,$_))
        {
	
		$e=(split(/-/,$token[10]))[1];
		$identity=$token[2];
		$len=$token[3];
		
		$r=$len/$length{$token[0]};
		if($e>=$_[1] && $identity>=$_[2] && $r>=$_[3])
		{
			$notwant{$token[0]}=0;
			$myid=(split(/\//,$token[0]))[0];
			$notwantid{$myid}=0;
		}
		else
		{
			
		}
		
        }
}
close(bl);
}
sub filter_seq{
open(seq,"$_[0]");
open(res,">$_[1]");
while(<seq>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$tmp_id=$id;
		$id=(split(/\s+/,$id))[0];
		$id=(split(/\//,$id))[0] if(grep(/\//,$id));

	
		
	}
	else
	{
		if(!exists($notwantid{$id}))
		{
			print res ">$tmp_id\n$_\n";
		}

	}

}
close(seq);
close(res);
open(res,">$_[3]");
open(gtf,"$_[2]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];
        print res $_."\n" if(!exists($notwantid{$tid}));
}
close(gtf);
close(res);
}

$out="$dir/res_file/blastx.myprotein.txt";
get_blast_res($out,$evalue,$identity,$len_ratio);

$res_fasta="$dir/res_file/filter_myprotein_blastx.fasta";
$res_gtf="$dir/res_file/filter_myprotein_blastx.gtf";
filter_seq($seq,$res_fasta,$gtf,$res_gtf);



