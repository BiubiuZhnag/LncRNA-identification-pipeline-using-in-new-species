$dir=$ARGV[0];
open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
	print $token[0]."\n";
}
close(param);
$org=$params{"organism"};
$org_select=$params{"org_select"}; 
$version=$params{"version"}; 

$known_pro_filetype=$params{"known_pro_filetype"};

if($org_select eq "known")
{
	

	$ref_gtf="data/"."$org".$version.".gtf";


	system("cuffcompare -i $files -r $ref_gtf -o $dir/res_file/ref -C");
}
else
{
	if($known_pro_filetype eq "gtf")
	{
		$ref_gtf="$dir/data/protein.gtf";
		system("cuffcompare -i $files -r $ref_gtf -o $dir/res_file/ref -C");
	}
}




