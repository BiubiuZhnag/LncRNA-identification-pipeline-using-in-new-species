$dir=$ARGV[0];
$seq=$ARGV[1];
#$seq2="../../".$seq;
$cpc_res="$dir/res_file/cpc.res";
chdir("software/cpc-0.9-r2/");
system("bin/run_predict.sh $seq $cpc_res");
chdir("../../");
