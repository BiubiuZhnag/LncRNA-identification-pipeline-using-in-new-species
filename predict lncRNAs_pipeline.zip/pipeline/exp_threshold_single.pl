use List::Util qw[min max];
%exp=();
%threshold=();
$dir=$ARGV[0];


sub getgtf{	
open(gtf,"$_[0]");
while(<gtf>)
{
                chomp;
                @token=split(/\t/,$_);
                if($token[2] ne "exon")
                {
                        $tran=(split(/\s+/,$token[8]))[3];
                        $tran=~s/"//g;
                        $tran=~s/;//g;
                        $fpkm=(split(/\s+/,$token[8]))[5];
                        $fpkm=~s/"//g;
                        $fpkm=~s/;//g;
                        $exp{$tran}=$fpkm;
			#		print $tran."\t".$fpkm."\n";
               }
}
close(gtf);
}

sub getcutoff
{
    open(refmap,"$_[0]");#
    while(<refmap>)
    {
                chomp;
                @token=split(/\t/,$_);
                @trans=split(/,/,$token[3]);
                foreach my $t(@trans)
                {
                        $t=(split(/\|/,$t))[1];
                        $hit{$t}=0 if($t ne "");
                }

    }
    close(refmap);
    open(res,">$dir/exp_threshold.txt");
    $all=keys(%exp);
    $true=keys(%hit);
    $r=$true/$all;
    $maxr=$r;
    $threshold{$maxr}=0;
    print res "0\t$true\t$all\t$r\t$score\n";
    print $_[1]."\n";
        for($i=0;$i<=$_[1];$i=$i+0.1) #�鿴exp��cutoff
        {
                $all1=0;
                $true1=0;

                while(my($k,$v)=each(%exp))
                {
                     $all1=$all1+1 if($v>=$i );
                     $true1=$true1+1 if(($v>=$i) and exists($hit{$k}));
                }
                $r1=$true1/$all1;
           
	        $score=$r1; 
                $maxr=max($maxr,$score);
                $threshold{$score}=$i;
                print res $i."\t$true1\t$all1\t$r1\t$score\n";
        }    
	close(res);
        $thre=$threshold{$maxr};
	return $thre;

}
sub expfilter_gtf_auto{

        while(my($k,$v)=each(%exp))
        {
                $want{$k}=0 if($v>=$_[1]);
        }

        open(gtf,"$_[0]");
	open(res,">$_[2]");
        while(<gtf>)
        {
                chomp;
                @token=split(/\t/,$_);
                $tran=(split(/\s+/,$token[8]))[3];
                $tran=~s/"//g;
                $tran=~s/;//g;
                print res $_."\n" if(exists($want{$tran}));
               


        }
        close(res);
        close(gtf);
}

sub expfilter_gtf_cutoff{

        while(my($k,$v)=each(%exp))
        {
                $want{$k}=0 if($v>=$_[1]);
        }

        open(gtf,"$_[0]");
	open(res,">$_[2]");
        while(<gtf>)
        {
                chomp;
                @token=split(/\t/,$_);
                $tran=(split(/\s+/,$token[8]))[3];
                $tran=~s/"//g;
                $tran=~s/;//g;
                print res $_."\n" if(exists($want{$tran}));
               


        }
        close(res);
        close(gtf);
}


open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
	print $token[0]."\n";
}
close(param);
$upload=$params{"upload_type"}; #single or multiple
$file_type=$params{"file_type"}; #gtf bed
$file_path=$params{"file_path"};
$exp_cutoff_type=$params{"exp_cutoff_type"}; #exp_cutoff or exp_auto
$cutoff=$params{"exp_auto_cutoff"};
$exp_thre=$params{"exp_cutoff"};

$gtf="$file_path/upload_file/1.gtf";
$res_gtf="$file_path/res_file/filter_exp.gtf";


if($file_type eq "gtf")
{
	if($exp_cutoff_type eq "exp_auto")
	{
		
		getgtf($gtf);
		$exp_thre=getcutoff($refmap,$cutoff);
		print $exp_thre."\n";
		expfilter_gtf_auto($gtf,$exp_thre,$res_gtf);

	}
	if($exp_cutoff_type eq "exp_cutoff")
	{
	
		getgtf($gtf);
		print "ddd\n";
		expfilter_gtf_cutoff($gtf,$exp_thre,$res_gtf);

	}
}

