$dir=$ARGV[0];
%recurance=();
sub getrec{
	%recurance=();
        open(tracking,"$_[0]");
        while(<tracking>)
        {
                chomp;
                @token=split(/\t/,$_);
                $rec=0;
                for($i=4;$i<@token;$i++)
                {
                        if($token[$i] ne "-")
                        {
                                $rec++;
                        }
                }
		$recurance{$token[0]}=$rec;
              
          }
          close(tracking);
}

sub recfilter_gtf{ #$_[2] recurranc cutoff
	
        open(gtf,"$_[0]");
	open(res,">$_[1]");
        while(<gtf>)
        {
                chomp;
                @token=split(/\t/,$_);
                $tran=(split(/\s+/,$token[8]))[3];
                $tran=~s/"//g;
                $tran=~s/;//g;
                print res $_."\n" if($recurance{$tran} >=$_[2]);
               
        }
        close(res);
        close(gtf);
}

open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];
}
close(param);
$rec_cutoff=$params{"rec_cutoff"};
$file_path=$params{"file_path"};


$tracking="$file_path/res_file/multi.tracking";
getrec($tracking);
$gtf="$file_path/res_file/multi.combined.gtf";
$res_gtf="$file_path/res_file/filter_rec.gtf";
recfilter_gtf($gtf,$res_gtf,$rec_cutoff);
#recfilter_gtf($ARGV[1],$ARGV[2],4);
