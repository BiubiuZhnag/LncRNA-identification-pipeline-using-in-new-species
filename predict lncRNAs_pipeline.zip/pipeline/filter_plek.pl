$dir=$ARGV[0];
$plek=$dir."/res_file/plek.res";
$seq=$ARGV[1];
$gtf=$ARGV[2];
open(plek,"$plek");
while(<plek>)
{
	chomp;
	@token=split(/\t/,$_);
	$token[2]=(split(/\s+/,$token[2]))[0];
	$token[2]=~s/^>//g;
	$non{$token[2]}=0 if($token[0] eq "Non-coding");
}
close(plek);

sub filter_seq{
open(seq,"$_[0]");
open(res,">$_[1]");
while(<seq>)
{
	chomp;
	if(grep(/^>/,$_))
	{
		$id=substr($_,1);
		$tmp_id=$id;
		$id=(split(/\s+/,$id))[0];
		$id=(split(/\//,$id))[0] if(grep(/\//,$id));
		
	}
	else
	{
		if(exists($non{$id}))
		{
			print res ">$tmp_id\n$_\n";
		}

	}

}
close(seq);
close(res);
open(res,">$_[3]");
open(gtf,"$_[2]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];
        print res $_."\n" if(exists($non{$tid}));
}
close(gtf);
close(res);
}

$res_fasta=$dir."/res_file/filter_plek.fasta";
$res_gtf=$dir."/res_file/filter_plek.gtf";
filter_seq($seq,$res_fasta,$gtf,$res_gtf);



