$dir=$ARGV[0];
$gtf=$ARGV[1];
$len_gtf="$dir/res_file/filter_len.gtf";

open(param,"$dir/request.txt");
while(<param>)
{
	chomp;
	@token=split(/\s+/,$_);
	$params{$token[0]}=$token[1];

}
close(param);
$len=$params{"min_seqlen"};
%len=();
sub getlen_fromgtf
{
open(gtf,"$_[0]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
        if($token[2] eq "exon")
        {
       
	$tid=(split(/"/,$token[8]))[3];
	$len{$tid}=$len{$tid}+$token[4]-$token[3];
        }
}
}
close(gtf);


sub filter_length_fromgtf
{
open(res,">$_[1]");
open(gtf,"$_[0]");
while(<gtf>)
{
        chomp;
	@token=split(/\t/,$_);
	$tid=(split(/"/,$token[8]))[3];
        print res $_."\n" if($len{$tid}>=$_[2]);
}
close(gtf);
close(res);



}

getlen_fromgtf($gtf);
filter_length_fromgtf($gtf,$len_gtf,$len);



